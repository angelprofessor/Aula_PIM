/*
 * ER/Studio Data Architect SQL Code Generation
 * Project :      ExemploMuitoSimples.DM1
 *
 * Date Created : Monday, April 13, 2020 18:16:14
 * Target DBMS : Microsoft SQL Server 2017
 */

IF OBJECT_ID('tbCotacaoMoedas') IS NOT NULL
BEGIN
    DROP TABLE tbCotacaoMoedas
    PRINT '<<< DROPPED TABLE tbCotacaoMoedas >>>'
END
go
/* 
 * TABLE: tbCotacaoMoedas 
 */

CREATE TABLE tbCotacaoMoedas(
    Data     datetime    NOT NULL,
    Valor    float       NOT NULL,
    CONSTRAINT PK1 PRIMARY KEY NONCLUSTERED (Data)
)
go



IF OBJECT_ID('tbCotacaoMoedas') IS NOT NULL
    PRINT '<<< CREATED TABLE tbCotacaoMoedas >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE tbCotacaoMoedas >>>'
go


