﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace ConsoleCotacao
{
    class Program
    {
        static void Main(string[] args)
        {
            string Data = "";
            float Valor=0;

            Console.Write("Entre com uma data:  ");
            Data = Console.ReadLine();

            Console.Write("Entre com um valor:  ");
            Valor = float.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

            dbCotacao.Cotacao cotacao = new dbCotacao.Cotacao();
            cotacao.Salvar(Data, Valor);

        }
    }
}
