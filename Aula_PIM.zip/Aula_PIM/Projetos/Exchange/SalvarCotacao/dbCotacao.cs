﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace dbCotacao
{
    public class Cotacao
    {
        public bool Salvar(string Data, float Valor)
        {
            bool ret = false;

            try
            {
                string strConexao = "Data Source=.;Initial Catalog=dbExchange;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(strConexao))
                {
                    using (SqlCommand cmd = new SqlCommand("sp_NovaCotacao", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@Data", SqlDbType.DateTime).Value = Data;
                        cmd.Parameters.Add("@Valor", SqlDbType.Float).Value = Valor;

                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch(Exception ex)
            {
                string err = ex.Message;

            }

            return ret;
        }
    }
}
