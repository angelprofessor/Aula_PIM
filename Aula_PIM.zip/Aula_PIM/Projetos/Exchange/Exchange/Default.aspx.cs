﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Exchange
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BtnSalvar_Click(object sender, EventArgs e)
        {
            dbCotacao.Cotacao cotacao = new dbCotacao.Cotacao();
            string Data = TxtData.Text.Trim();
            float Valor = float.Parse(TxtValor.Text, CultureInfo.InvariantCulture);
            cotacao.Salvar(Data, Valor);

            TxtValor.Text = "";
            TxtData.Text = "";
        }
    }
}