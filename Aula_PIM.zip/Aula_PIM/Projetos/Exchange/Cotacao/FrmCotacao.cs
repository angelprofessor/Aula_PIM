﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Cotacao
{
    public partial class FrmCotacao : Form
    {
        public FrmCotacao()
        {
            InitializeComponent();
        }

        private void BtnSalvarCotacao_Click(object sender, EventArgs e)
        {
            dbCotacao.Cotacao cotacao = new dbCotacao.Cotacao();
            string Data = TxtData.Text.Trim();
            float Valor = float.Parse(TxtValor.Text, CultureInfo.InvariantCulture);
            cotacao.Salvar(Data, Valor);
            TxtValor.Text = "";
            TxtData.Text = "";
        }
    }
}
